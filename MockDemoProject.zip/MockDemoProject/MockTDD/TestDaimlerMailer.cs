﻿using MockDemoProject;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockTDD
{
    [TestFixture]
    public class TestDaimlerMailer
    {
        private DaimlerMailer daimlerMailer;
        

        [Test]
        public void SendMailReturnsTrue()
        {
            //create mock object
            var mailClient = new Moq.Mock<IMailClient>();
            mailClient.SetupProperty(client=>client.MailServer,"smtp.gmail.com").
                SetupProperty(client=>client.Port,"587")
                .SetupProperty(client=>client.SSL,true);

            mailClient.Setup(client => client.ClientSendMail(It.IsAny<String>(),
                It.IsAny<String>(), It.IsAny<String>(), It.IsAny<String>())).Returns(true);


            daimlerMailer = new DaimlerMailer
            {
                From = "Parameswaribala@gmail.com",
                To = "balamanick@gmail.com",
                Subject = "Training",
                Body = "Training scheduled on TDD"
            };
            Assert.IsTrue(daimlerMailer.SendMail(mailClient.Object));


        }




    }
}
