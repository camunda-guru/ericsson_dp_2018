﻿namespace MockDemoProject
{
    public interface IMailClient
    {
        string MailServer { get; set; }
        string Port { get; set; }
        bool SSL { get; set; }
        bool ClientSendMail(string From, string To, 
            string Subject, string Body);

    }
}