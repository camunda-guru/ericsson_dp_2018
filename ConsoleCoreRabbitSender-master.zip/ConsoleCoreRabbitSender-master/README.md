# ConsoleCoreRabbitSender
Console application in ASP.NET Core 2.0 that will using RabbitMQ to send messages
https://github.com/devravi93/ConsoleCoreRabbitReceiver click here for the sender part of the same. for the explanantion of above code, please visit https://www.c-sharpcorner.com/members/ravi-raghav2 and find this article.
