import {Component, OnInit} from "@angular/core";
import {CountryService} from "../service/service.country";
import {DataSource} from "@angular/cdk/collections";
import {Observable} from "rxjs/Observable";


@Component({

    templateUrl:'./home/feedback/feedback.component.html',
    styleUrls:['./home/feedback/feedback.component.css']

})
export class FeedbackComponent implements OnInit
{

    private users:any;
    private filterChar:string="P";
    private tableSource=  new TableDataSource(this.countryServiceObj);
    displayedColumns = ['mobileNo', 'firstName','lastName','email','country','state','dob','gender'];
    constructor(private countryServiceObj:CountryService)
    {

    }

    ngOnInit() {
        this.countryServiceObj.getAllUsers().subscribe(response => {
            console.log(response);
            this.users=response;
        })
    }




}


export class TableDataSource extends DataSource<any>{

    constructor(private countryServiceObj:CountryService)
    {
        super()
    }
    connect():Observable<any[]>
    {
      return this.countryServiceObj.getAllUsers();
    }
    disconnect() {}
}
