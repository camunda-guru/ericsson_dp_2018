import {Pipe, PipeTransform} from "@angular/core";

@Pipe({name:'EmailFilter'})
export class UserFilter implements PipeTransform{
    transform(value: any, searchChar:string): any
    {
         console.log(value);
         console.log(searchChar);
        return value.filter(obj=>obj.email.startsWith(searchChar));
    }
}