import {Component} from "@angular/core";


@Component({
    templateUrl:'./home/electronics/electronics.component.html',
    styleUrls:['./home/electronics/electronics.component.css']
})
export class ElectronicsComponent{

}