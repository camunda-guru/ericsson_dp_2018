import {State} from "./model.state";

export var stateData:State[]=[

    new State(1,"TamilNadu","IND"),
    new State(2,"Karnataka","IND"),
    new State(3,"Kerala","IND"),
    new State(4,"Telengana","IND"),
    new State(1,"California","USA"),
    new State(2,"Boston","USA"),
    new State(3,"Texas","USA"),


]
