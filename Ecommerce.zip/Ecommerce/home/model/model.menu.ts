export class Menu{

    private menuCode:number;
    private menuName:string;

    constructor(code:number,mname:string)
    {
        this.menuCode=code;
        this.menuName=mname;
    }

    get MenuCode():number
    {
        return this.menuCode;
    }
    get MenuName():string
    {
        return this.menuName;
    }
}
