import {Component, OnInit, ViewChild, ViewContainerRef} from "@angular/core";



@Component({
    templateUrl:'./home/furniture/furniture.component.html',
    styleUrls:['./home/furniture/furniture.component.css']
})
export class FurnitureComponent{

}