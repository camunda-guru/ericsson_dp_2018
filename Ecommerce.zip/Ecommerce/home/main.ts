import {platformBrowserDynamic} from "@angular/platform-browser-dynamic";
import {HomeModule} from "./home.module";


platformBrowserDynamic().bootstrapModule(HomeModule);