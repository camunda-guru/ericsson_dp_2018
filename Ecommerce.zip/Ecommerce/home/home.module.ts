import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {HomeComponent} from "./home.component";
import {HeaderComponent} from "./header/header.component";
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./service/service.menuservice";
import {HomeRoutingModule} from "./home.routing";
import {
    MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule, MatRadioModule,
    MatSelectModule, MatSnackBarModule, MatTableModule, MatTabsModule
} from "@angular/material";
import {LoginComponent} from "./login/login.component";
import {RegisterComponent, SaveRecordComponent} from "./register/register.component";
import {ProductModule} from "./product/product.module";
import {AuthService} from "./service/service.authenticationservice";
import {AuthGuardService} from "./service/service.authguard";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {HttpClientModule} from "@angular/common/http";
import {CountryService} from "./service/service.country";
import {MyPostComponent} from "./dynamic/dynamic.postcomponent";
import {MyPostBannerComponent} from "./dynamic/dynamic.postbanner";
import {ArticleComponent} from "./dynamic/dynamic.articlecomponent";
import {TechnologyComponent} from "./dynamic/dynamic.technicalcomponent";
import {MyPostDirective} from "./dynamic/dynamic.postdirective";
import {MyPostService} from "./service/service.dynamicservice";
import {FeedbackComponent} from "./feedback/feedback.component";
import {UserFilter} from "./filters/filters.userfilter";


//sub module added  before main routing module
@NgModule({
    imports:[BrowserModule,ProductModule,HomeRoutingModule,
        MatButtonModule,MatFormFieldModule,
        MatInputModule,MatRadioModule,FormsModule,ReactiveFormsModule,MatIconModule,
        BrowserAnimationsModule,HttpClientModule,MatTableModule,MatSelectModule,MatSnackBarModule,MatTabsModule],
    declarations:[HomeComponent,HeaderComponent,MenuComponent,FeedbackComponent,
        LoginComponent,RegisterComponent,SaveRecordComponent,MyPostComponent,MyPostBannerComponent,ArticleComponent,TechnologyComponent,MyPostDirective,UserFilter],
    entryComponents: [SaveRecordComponent,ArticleComponent,TechnologyComponent ],
    providers:[MenuService,AuthService,AuthGuardService,CountryService,MyPostService],
    bootstrap:[HomeComponent]
})
export class HomeModule
{

}