import {Component, OnInit} from "@angular/core";
import {MenuService} from "../service/service.menuservice";


@Component({
    templateUrl:'./home/product/product.component.html',
    styleUrls:['./home/product/product.component.css']
})
export class ProductComponent implements OnInit{
    private submenuData:any;
    constructor(private menuServiceObj:MenuService)
    {
        console.log("hitting....")
    }
    ngOnInit()
    {
      this.submenuData=this.menuServiceObj.getProductSubMenu();
      console.log(this.submenuData);
    }

}