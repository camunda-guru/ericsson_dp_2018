﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FluentStoredProcedure
{
    class Trainer
    {
        public virtual int TrainerId{get;set;}
        public virtual String TrainerName { get; set; }
        public virtual int YOE { get; set; }
    }
}
