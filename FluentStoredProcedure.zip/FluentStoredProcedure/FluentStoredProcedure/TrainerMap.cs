﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentNHibernate.Mapping;

namespace FluentStoredProcedure
{
    class TrainerMap:ClassMap<Trainer>
    {
        public TrainerMap()
        {
            Id(x => x.TrainerId);
            Map(x => x.TrainerName);
            Map(x => x.YOE);


        }
    }
}
