﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Transform;

namespace FluentStoredProcedure
{
    class Program
    {
        const String conn = "Data Source=BALA-VAIO;Initial Catalog=USTDEMODB;User ID=sa;Password=vignesh"; 
        static void Main(string[] args)
        {
          //  Fluently.Configure().Database(MsSqlConfiguration.MsSql2008.ConnectionString(conn)).Mappings(m => m.FluentMappings.AddFromAssemblyOf<TrainerMap>()).ExposeConfiguration(CreateSchema).BuildConfiguration();
           // Console.WriteLine("Table Created");
            ISessionFactory sessionfact = CreateSessionFactory();
            ISession session = sessionfact.OpenSession();
            //Trainer trainer = new Trainer { TrainerName="Parameswari",YOE=21};
            //using (session.BeginTransaction())
            //{
            //    session.Save(trainer);
            //    trainer = new Trainer { TrainerName = "Bala", YOE = 27 };
            //    session.Save(trainer);
            //    trainer = new Trainer { TrainerName = "Vignesh", YOE = 7 };
            //    session.Save(trainer);
            //    session.Transaction.Commit();

            //}
            //Console.WriteLine("Records Created");

            IQuery query = session.GetNamedQuery("GetTrainerDetails").SetInt32("TrId", 2).SetResultTransformer(new AliasToBeanResultTransformer(typeof(Trainer)));
            IList<Trainer> list = query.List<Trainer>();
            foreach (Trainer tr in list)
                Console.WriteLine(tr.TrainerName);
            
                
                Console.ReadKey();
        }

        static void CreateSchema(Configuration cfg)
        {
            var schemaexport = new SchemaExport(cfg);
            schemaexport.Create(false, true);


        }
        static ISessionFactory CreateSessionFactory()
        {

            return Fluently.Configure().Database(MsSqlConfiguration.MsSql2008.ConnectionString(conn)).Mappings(m =>
            {
                m.FluentMappings.AddFromAssemblyOf<TrainerMap>();
                m.HbmMappings.AddFromAssemblyOf<Trainer>();
                m.MergeMappings();
            }).BuildSessionFactory();

        }
    }
}
